from utils import *

variables = ['X', 'Y', 'Z']

values = {'X':[True, False], 'Y':[True, False], 'Z':[True, False]}

events = enumerate_events(variables, values)

